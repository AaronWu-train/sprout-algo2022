#ifndef _MAHJONG_H_
#define _MAHJONG_H_
#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <sstream>
#include <math.h>
using namespace std;

void play(); // playing function: student write

string check(vector<string> cards); // check

#endif
